# THE AFTERGLOW — Android wrapper project

Am pregătit un proiect Android Studio care încarcă jocul web furnizat în WebView.
Am eliminat din copia pentru Android apelul cunoscut către scriptul de pop-under
(acscdn.com / zoneId 12409534). Restul jocului a fost păstrat.

## IMPORTANT — înainte de publicare
Acesta este un proiect-sursă pregătit pentru Android Studio, NU un AAB semnat și
NU este încă pregătit pentru încărcare directă în Play Console.

1. Deschide proiectul `TheAfterglow` în Android Studio și lasă Gradle Sync să termine.
2. În `app/build.gradle`, schimbă:
   - `applicationId` din `com.example.theafterglow` în ID-ul EXACT al aplicației deja
     existente în Google Play Console (dacă aceasta este o actualizare).
   - `versionCode` într-un număr mai mare decât cel al oricărei versiuni încărcate
     anterior în Play Console.
   - `versionName` după cum dorești.
3. Schimbă și `namespace` din `app/build.gradle`, precum și pachetul Java și calea
   clasei `MainActivity.java` dacă alegi alt namespace.
4. Testează jocul pe un telefon real, inclusiv comenzile tactile, afișarea peisaj,
   încărcarea imaginilor și funcțiile care folosesc internetul.
5. În Android Studio: Build > Generate Signed Bundle / APK > Android App Bundle.
   Folosește cheia de semnare ORIGINALĂ a aplicației existente dacă publici o
   actualizare. Nu pierde și nu distribui cheia privată.
6. Încarcă AAB-ul rezultat în pista de testare internă.

## Observații
- Jocul folosește resurse externe (de exemplu Three.js și imagini) și are nevoie
  de conexiune la internet.
- Am păstrat codul jocului și funcțiile sale; nu am putut valida funcționarea
  serviciilor externe sau politicile fiecărui furnizor.
- Verifică în Play Console cerințele actuale privind target API, declarațiile,
  confidențialitatea, reclamele și conținutul înainte de publicare.
- Nu trimite nimănui parola Google sau fișierul de cheie de semnare.
